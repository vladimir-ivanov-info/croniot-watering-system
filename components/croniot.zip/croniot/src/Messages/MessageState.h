/*#ifndef MESSAGESTATE_H
#define MESSAGESTATE_H

#include <cJSON.h>

class MessageState {
public:
    MessageState(const String& currentTime, const String& wifiStrength, const String& chipTemperature, const String& batteryVoltage); // Constructor

    String toJson();

private:
    String messageName = "MESSAGE_STATE";
    String currentTime;
    String wifiStrength;
    String chipTemperature;
    String batteryVoltage;
};

#endif
*/




#ifndef MESSAGESTATE_H
#define MESSAGESTATE_H

#include <string>

class MessageState {
public:
    MessageState(const std::string& currentTime,
                 const std::string& wifiStrength,
                 const std::string& chipTemperature,
                 const std::string& batteryVoltage);

    std::string toJson() const;

private:
    const std::string messageName = "MESSAGE_STATE";
    std::string currentTime;
    std::string wifiStrength;
    std::string chipTemperature;
    std::string batteryVoltage;
};

#endif
