/*#include "MessageRegisterSensorType.h"

JsonObject MessageRegisterSensorType::toJson(JsonObject root) {
    JsonObject sensorObj = root["sensorType"].to<JsonObject>();

    sensor.toJson(sensorObj);

    root["deviceUuid"] = deviceUuid;
    root["deviceToken"] = deviceToken;

    return root;
}*/

#include "MessageRegisterSensorType.h"
#include "cJSON.h"

MessageRegisterSensorType::MessageRegisterSensorType(const std::string& deviceUuid,
                                                     const std::string& deviceToken,
                                                     const SensorType& sensor)
    : deviceUuid(deviceUuid), deviceToken(deviceToken), sensor(sensor) {}



cJSON* MessageRegisterSensorType::toJson() const {
    cJSON* root = cJSON_CreateObject();

    // Agregar UUID y token
    cJSON_AddStringToObject(root, "deviceUuid", deviceUuid.c_str());
    cJSON_AddStringToObject(root, "deviceToken", deviceToken.c_str());

    // Agregar sensorType como objeto anidado
    cJSON* sensorObj = cJSON_CreateObject();
    sensor.toJson(sensorObj);  // Este método debe rellenar el objeto cJSON con los campos del sensor
    cJSON_AddItemToObject(root, "sensorType", sensorObj);

    return root;
}

std::string MessageRegisterSensorType::toJsonString() const {
    cJSON* root = toJson();  // usa tu función existente
    char* jsonStr = cJSON_PrintUnformatted(root);  // convierte a char*

    std::string result(jsonStr);  // crea std::string desde char*
    cJSON_Delete(root);  // libera cJSON
    free(jsonStr);       // libera string C

    return result;
}
