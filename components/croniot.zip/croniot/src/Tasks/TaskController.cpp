/*#include "TaskController.h"

extern String DEVICE_UUID_EXTERN;


void TaskController::init(){
    for(TaskBase *task : tasks){
        task->run();
    }

    Serial.println("TaskController initialized...");
    xTaskCreatePinnedToCore(taskFunction, "TaskController", 4096, this, 1, &taskHandle, 1);
    xTaskCreatePinnedToCore(taskProgressUpdateFunction, "TaskProgressUpdateFunction", 2*4096, this, 1, &taskProgressUpdateHandle, 1);
}


void TaskController::taskFunction(void* pvParameters) {
    TaskController* taskInstance = static_cast<TaskController*>(pvParameters);

    Serial.println("TaskController task initialized...");

    while (true) {
        vTaskDelay(1*1000 / portTICK_PERIOD_MS);

        std::map<int, String> currentTasks = Storage::instance().getTasksForCurrentDateTime();

        for(auto taskParameters: currentTasks){

            int taskUid = taskParameters.first;

            std::map<int, String> parameters = taskInstance->stringToMap(taskParameters.second);
            SimpleTaskData simpleTaskData(taskUid, parameters);

            Serial.print("Task will be executed now:"); Serial.println(taskUid);

            for(TaskBase *task : taskInstance->tasks){
                if(task->getUid() == taskUid){
                    task->enqueueMessage(simpleTaskData);
                }
            }
        }
    }
}

void TaskController::taskProgressUpdateFunction(void* pvParameters) {
    TaskController* taskInstance = static_cast<TaskController*>(pvParameters);

    while(true){
        TaskProgressUpdate *taskProgressUpdate;
        if(xQueueReceive(taskInstance->progressUpdateQueue, &taskProgressUpdate, portMAX_DELAY) == pdPASS){
            
            int taskUid = taskProgressUpdate->taskUid;

            String topic = "/iot_to_server/task_progress_update/" + DEVICE_UUID_EXTERN; //TODO fix later, parametrize

            String message = taskProgressUpdate->toJson();
            Serial.println("Publishing to " + topic);
            Serial.println(message);
            MqttProvider::get()->publish(topic, message);
        }
    }
}

std::map<int, String> TaskController::stringToMap(String input) {
    std::map<int, String> result;
    int start = 0;

    // Print the entire input string for debugging
    //Serial.println("Input String:");
    //Serial.println(input);

    while (start < input.length()) {
        // Find the index of the next newline
        int end = input.indexOf('\n', start);
        if (end == -1) {
            end = input.length(); // Handle the case where the last line doesn't have a newline
        }

        // Extract the current line
        String line = input.substring(start, end);

        // Print the line to see what is being processed
        Serial.print("Processing line: ");
        Serial.println(line);

        // Find the separator between key and value (assumed to be '=')
        int separatorIndex = line.indexOf('=');
        if (separatorIndex != -1) {
            // Extract key and value
            String keyString = line.substring(0, separatorIndex);
            int key = keyString.toInt(); // Convert key to int

            // Print extracted key
            Serial.print("Extracted key: ");
            Serial.println(keyString);

            // If the key is 0 but the keyString is not "0", skip it
            if (key == 0 && keyString != "0") {
                Serial.println("Skipping invalid key (non-numeric): " + keyString);
            } else {
                String value = line.substring(separatorIndex + 1); // Extract value

                // Print extracted value
                Serial.print("Extracted value: ");
                Serial.println(value);

                // Insert into the map
                result[key] = value;
            }
        } else {
            Serial.println("No '=' found in line, skipping...");
        }

        // Move to the next line
        start = end + 1;
    }

    // Debug the map content after processing
    Serial.println("Map content:");
    for (auto const& pair : result) {
        Serial.print("Key: ");
        Serial.print(pair.first);
        Serial.print(", Value: ");
        Serial.println(pair.second);
    }

    // Print the map size
    Serial.print("Final map size: ");
    Serial.println(result.size());

    return result;
}

TaskData TaskController::processMessage(String message){

    TaskData taskData;
    JsonDocument doc;

    // Deserialize the JSON string
    DeserializationError error = deserializeJson(doc, message);

    // Check for errors
    if (error) {
        Serial.print(F("deserializeJson() failed: "));
        Serial.println(error.f_str());
        // Return a default Result object with success as false and empty message
        //return Result(false, "Local deserializeJson() failed, JSON:\n" + jsonString);
    } else {
        //int taskTypeUid = doc["taskTypeUid"];
        int taskUid = doc["taskUid"];
        int taskTypeUid = doc["taskTypeUid"];

        std::map<int, String> parametersValuesForTask;

        JsonObject parametersValues = doc["parametersValues"].as<JsonObject>();

        Serial.println();
        //Serial.print("TaskType uid: "); Serial.println(taskTypeUid);
        Serial.print("Task uid: "); Serial.println(taskUid);
        for (JsonPair kv : parametersValues) {
            const char* key = kv.key().c_str();
            int intKey = atoi(key); // Convert the key to an integer
            String value = kv.value().as<String>();
            Serial.print("Parameter: ["); Serial.print(intKey);  Serial.print("]");
            Serial.print(" value: [" + value); Serial.print("]");
            Serial.println();

            parametersValuesForTask.insert(std::make_pair(intKey, value));
        }
        taskData.taskTypeUid = taskTypeUid;
        taskData.taskUid = taskUid;
        taskData.parametersValues = parametersValuesForTask;
    }

    return taskData;
}

void TaskController::registerCallback(String deviceUuid, int taskTypeUid, TaskBase* taskInstance){
    tasksMap[taskTypeUid] = taskInstance;

    String listenTopic = "/server/" + String(deviceUuid) + "/task_type/" + String(taskTypeUid);
    Serial.println("Mqtt listening topic: " + listenTopic);
    MqttProvider::get()->registerCallback(listenTopic, taskInstance);
}

void TaskController::processMessage(int taskTypeUid, String message, unsigned int length){
    Serial.println(message);
    TaskData taskData = processMessage(message);

    TaskProgressUpdate taskProgressUpdate(taskData.taskTypeUid, taskData.taskUid, "RECEIVED", 0.0, ""); 
    TaskController::instance().enqueueTaskProgressUpdate(taskProgressUpdate);

    if(taskData.parametersValues.find(COMMON_TASK_PARAMETER_TIME) != taskData.parametersValues.end()){

        //if time is now:
        String time = taskData.parametersValues[COMMON_TASK_PARAMETER_TIME];
        if(CurrentDateTimeController::instance().isCurrentTime(time)){
            runTaskRightNow(taskData);
        } else {
            Storage::instance().saveFutureTask(taskTypeUid, taskData);
        }
    } else {
        runTaskRightNow(taskData);
    }
}

void TaskController::runTaskRightNow(TaskData &taskData){
    int taskTypeUid = taskData.taskTypeUid;

    SimpleTaskData simpleTaskData(taskData.taskUid, taskData.parametersValues);

    Serial.println("Received task type uid: " + taskTypeUid);

    for(TaskBase *task : tasks){
        Serial.println("TaskType uid:" + task->getUid());
        if(task->getUid() == taskTypeUid){
            //Serial.println("Enqueuing: " + parameters);
            task->enqueueMessage(simpleTaskData);
        }
    }
}



String TaskController::byteArrayToString(uint8_t* data, unsigned int length) {
    // Create a temporary char array to hold the data
    char* temp = new char[length + 1]; // +1 for the null terminator
    memcpy(temp, data, length);
    temp[length] = '\0'; // Null terminate the string

    // Create a String from the char array
    String result = String(temp);

    // Clean up the temporary char array
    delete[] temp;

    return result;
};

void TaskController::enqueueTaskProgressUpdate(TaskProgressUpdate& taskProgressUpdate){
    if (progressUpdateQueue == NULL) {
        Serial.println("Message queue is NULL. Cannot enqueue message.");
        return;
    }

    // Dynamically allocate a copy of TaskData
    TaskProgressUpdate* taskProgressUpdateCopy = new TaskProgressUpdate(taskProgressUpdate);
    if (taskProgressUpdateCopy == NULL) {
        Serial.println("Failed to allocate memory for TaskData.");
        return;
    }

    // Enqueue the pointer to TaskData
    if (xQueueSend(progressUpdateQueue, &taskProgressUpdateCopy, portMAX_DELAY) != pdPASS) {
        Serial.println("Failed to enqueue TaskData.");
        delete taskProgressUpdateCopy; // Free the allocated memory if enqueue fails
    }
}

*/

#include <sstream>  // <--- necesario para std::istringstream
#include <map>
#include <string>
#include "esp_log.h"
#include "cJSON.h"
#include "TaskController.h"

extern std::string DEVICE_UUID_EXTERN;

void TaskController::init(){
    /*for(TaskBase *task : tasks){
        task->run();
    }*/

    ESP_LOGI("TaskController", "Initialized...");
        //xTaskCreatePinnedToCore(taskFunction, "TaskController", 4096, this, 1, &taskHandle, 1);
 //   xTaskCreate(taskFunction, "TaskController", 4096, this, 1, &taskHandle);
        //xTaskCreatePinnedToCore(taskProgressUpdateFunction, "TaskProgressUpdateFunction", 2*4096, this, 1, &taskProgressUpdateHandle, 1);
 //   xTaskCreate(taskProgressUpdateFunction, "TaskProgressUpdateFunction", 2*4096, this, 1, &taskProgressUpdateHandle);

}

void TaskController::taskFunction(void* pvParameters) {
    TaskController* taskInstance = static_cast<TaskController*>(pvParameters);

    ESP_LOGI("TaskController", "Task loop2 running...");

    /*while (true) {
        vTaskDelay(1000 / portTICK_PERIOD_MS);

        auto currentTasks = Storage::instance().getTasksForCurrentDateTime();

        for(const auto& taskParameters: currentTasks){
            int taskUid = taskParameters.first;
            auto parameters = taskInstance->stringToMap(taskParameters.second);
            SimpleTaskData simpleTaskData(taskUid, parameters);

            ESP_LOGI("TaskController", "Executing Task UID: %d", taskUid);

            for(TaskBase *task : taskInstance->tasks){
                if(task->getUid() == taskUid){
                    task->enqueueMessage(simpleTaskData);
                }
            }
        }
    }*/
}

void TaskController::taskProgressUpdateFunction(void* pvParameters) {
    TaskController* taskInstance = static_cast<TaskController*>(pvParameters);

    while(true){
        TaskProgressUpdate *taskProgressUpdate;
        if(xQueueReceive(taskInstance->progressUpdateQueue, &taskProgressUpdate, portMAX_DELAY) == pdPASS){
            int taskUid = taskProgressUpdate->taskUid;

            std::string topic = "/iot_to_server/task_progress_update/" + DEVICE_UUID_EXTERN;
            std::string message = taskProgressUpdate->toJson();

            ESP_LOGI("TaskController", "Publishing to %s", topic.c_str());
            ESP_LOGI("TaskController", "%s", message.c_str());
            MqttProvider::get()->publish(topic, message);
        }
    }
}

std::map<int, std::string> TaskController::stringToMap(const std::string& input) {
    std::map<int, std::string> result;
    std::istringstream stream(input);
    std::string line;

    while (std::getline(stream, line)) {
        auto pos = line.find('=');
        if (pos == std::string::npos) continue;

        std::string keyStr = line.substr(0, pos);
        std::string value = line.substr(pos + 1);
        //TODO:
        //try {
            int key = std::stoi(keyStr);
            result[key] = value;
        //} catch (...) {
       //     continue;
        //}
    }

    return result;
}

/*TaskData TaskController::processMessage(const std::string& message){
    TaskData taskData;
    JsonDocument doc;

    if (deserializeJson(doc, message).failed()) {
        ESP_LOGE("TaskController", "JSON parse failed");
        return taskData;
    }

    taskData.taskUid = doc["taskUid"];
    taskData.taskTypeUid = doc["taskTypeUid"];

    JsonObject values = doc["parametersValues"].as<JsonObject>();
    for (JsonPair kv : values) {
        int key = atoi(kv.key().c_str());
        std::string value = kv.value().as<std::string>();
        taskData.parametersValues[key] = value;
    }

    return taskData;
}*/



TaskData TaskController::processMessage(const std::string& message) {
    TaskData taskData;

    cJSON* root = cJSON_Parse(message.c_str());
    if (!root) {
        ESP_LOGE("TaskController", "JSON parse failed");
        return taskData;
    }

    // Leer taskUid y taskTypeUid
    cJSON* taskUid = cJSON_GetObjectItem(root, "taskUid");
    cJSON* taskTypeUid = cJSON_GetObjectItem(root, "taskTypeUid");
    if (cJSON_IsNumber(taskUid)) {
        taskData.taskUid = taskUid->valueint;
    }
    if (cJSON_IsNumber(taskTypeUid)) {
        taskData.taskTypeUid = taskTypeUid->valueint;
    }

    // Leer parametersValues
    cJSON* parametersValues = cJSON_GetObjectItem(root, "parametersValues");
    if (cJSON_IsObject(parametersValues)) {
        cJSON* item = parametersValues->child;
        while (item != nullptr) {
            int key = atoi(item->string);
            std::string value = cJSON_IsString(item) ? item->valuestring : "";

            taskData.parametersValues[key] = value;

            item = item->next;
        }
    }

    cJSON_Delete(root);
    return taskData;
}


void TaskController::registerCallback(const std::string& deviceUuid, int taskTypeUid, TaskBase* taskInstance){
    tasksMap[taskTypeUid] = taskInstance;
    std::string topic = "/server/" + deviceUuid + "/task_type/" + std::to_string(taskTypeUid);
    ESP_LOGI("TaskController", "MQTT listening topic: %s", topic.c_str());
    MqttProvider::get()->registerCallback(topic, taskInstance);
}

void TaskController::processMessage(int taskTypeUid, const std::string& message, unsigned int length){
    TaskData taskData = processMessage(message);

    TaskProgressUpdate update(taskData.taskTypeUid, taskData.taskUid, "RECEIVED", 0.0, "");
    enqueueTaskProgressUpdate(update);

    if(taskData.parametersValues.find(COMMON_TASK_PARAMETER_TIME) != taskData.parametersValues.end()){
        std::string time = taskData.parametersValues[COMMON_TASK_PARAMETER_TIME];
        if(CurrentDateTimeController::instance().isCurrentTime(time)){
            runTaskRightNow(taskData);
        } else {
            Storage::instance().saveFutureTask(taskTypeUid, taskData);
        }
    } else {
        runTaskRightNow(taskData);
    }
}

void TaskController::runTaskRightNow(TaskData& taskData){
    SimpleTaskData simpleData(taskData.taskUid, taskData.parametersValues);

    ESP_LOGI("TaskController", "Run task type UID: %d", taskData.taskTypeUid);

    for(TaskBase *task : tasks){
        if(task->getUid() == taskData.taskTypeUid){
            task->enqueueMessage(simpleData);
        }
    }
}

std::string TaskController::byteArrayToString(uint8_t* data, unsigned int length) {
    return std::string(reinterpret_cast<char*>(data), length);
}

void TaskController::enqueueTaskProgressUpdate(TaskProgressUpdate& taskProgressUpdate){
    if (progressUpdateQueue == nullptr) return;

    auto* copy = new TaskProgressUpdate(taskProgressUpdate);
    if (!copy) return;

    if (xQueueSend(progressUpdateQueue, &copy, portMAX_DELAY) != pdPASS) {
        delete copy;
    }
}

