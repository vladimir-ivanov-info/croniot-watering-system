// #include "CommonSetup.h"
// #include <WiFi.h>

// bool CommonSetup::setupImpl(UserCredentials userCredentials, NetworkConnectionControllerBase* networkConnectionController){

//   //setup HTTP controller
//   UserCredentials credentialsInMemory = Storage::instance().readUserCredentials();

//   Serial.print("Credentials in memory: [");
//   Serial.print(credentialsInMemory.accountEmail);
//   Serial.print(",");
//   Serial.print(credentialsInMemory.accountUuid);
//   Serial.print(",");
//   Serial.print(credentialsInMemory.accountPassword);
//   Serial.print(",");
//   Serial.print(credentialsInMemory.deviceUuid);
//   Serial.print(",");
//   Serial.print(credentialsInMemory.deviceName);
//   Serial.print(",");
//   Serial.print(credentialsInMemory.deviceDescription);
//   Serial.println("]");

//   Serial.print("Credentials defined by user: [");
//   Serial.print(userCredentials.accountEmail);
//   Serial.print(",");
//   Serial.print(userCredentials.accountUuid);
//   Serial.print(",");
//   Serial.print(userCredentials.accountPassword);
//   Serial.print(",");
//   Serial.print(userCredentials.deviceUuid);
//   Serial.print(",");
//   Serial.print(userCredentials.deviceName);
//   Serial.print(",");
//   Serial.print(userCredentials.deviceDescription);
//   Serial.println("]");


//   if(credentialsInMemory.accountEmail != userCredentials.accountEmail 
//   || credentialsInMemory.accountUuid != userCredentials.accountUuid
//   || credentialsInMemory.accountPassword != userCredentials.accountPassword 
//   || credentialsInMemory.deviceUuid != userCredentials.deviceUuid
//   || credentialsInMemory.deviceName != userCredentials.deviceName){

//     Serial.println("Storing new credentials");

//     UserCredentials newCredentials = 
//         UserCredentials(userCredentials.accountEmail, userCredentials.accountUuid, userCredentials.accountPassword, userCredentials.deviceUuid, "", userCredentials.deviceName, userCredentials.deviceDescription);
    
//     Storage::instance().saveUserCredentials(newCredentials);
//     vTaskDelay(500 / portTICK_PERIOD_MS);

//    // return true;
//   }

//   authenticateWithServer(networkConnectionController);

//   return false; //TODO
// }

// void CommonSetup::authenticateWithServer(NetworkConnectionControllerBase* networkConnectionController){
//   bool networkConnectionProviderInitialized = NetworkConnectionProvider::init(networkConnectionController);

//   if(networkConnectionProviderInitialized){
//     bool authenticated = AuthenticationController::instance().init();

//     if(authenticated){
//       Serial.println("###AUTHENTICATED WITH SERVER");
//       bool mqttInitialized = MqttProvider::get()->init();

//       if(mqttInitialized){
//         SensorsController::instance().init();
//       } else {
//         Serial.println("Could not initialize MQTT...");
//       }
      
//     }
//   } else {
//     //TODO
//     Serial.println("Could not initialize network connection provider... Is server on?"); //TODO ping to check if server on
//   }
// }




#include "CommonSetup.h"
#include "esp_log.h"

static const char* TAG = "CommonSetup";

bool CommonSetup::setupImpl(UserCredentials userCredentials, NetworkConnectionControllerBase* networkConnectionController) {
    UserCredentials credentialsInMemory = Storage::instance().readUserCredentials();

    ESP_LOGI(TAG, "Credentials in memory: [%s,%s,%s,%s,%s,%s]",
             credentialsInMemory.accountEmail.c_str(),
             credentialsInMemory.accountUuid.c_str(),
             credentialsInMemory.accountPassword.c_str(),
             credentialsInMemory.deviceUuid.c_str(),
             credentialsInMemory.deviceName.c_str(),
             credentialsInMemory.deviceDescription.c_str());

    ESP_LOGI(TAG, "Credentials defined by user: [%s,%s,%s,%s,%s,%s]",
             userCredentials.accountEmail.c_str(),
             userCredentials.accountUuid.c_str(),
             userCredentials.accountPassword.c_str(),
             userCredentials.deviceUuid.c_str(),
             userCredentials.deviceName.c_str(),
             userCredentials.deviceDescription.c_str());

    if (credentialsInMemory.accountEmail != userCredentials.accountEmail ||
        credentialsInMemory.accountUuid != userCredentials.accountUuid ||
        credentialsInMemory.accountPassword != userCredentials.accountPassword ||
        credentialsInMemory.deviceUuid != userCredentials.deviceUuid ||
        credentialsInMemory.deviceName != userCredentials.deviceName) {

        ESP_LOGI(TAG, "Storing new credentials");

        UserCredentials newCredentials = UserCredentials(
            userCredentials.accountEmail, userCredentials.accountUuid,
            userCredentials.accountPassword, userCredentials.deviceUuid,
            "", userCredentials.deviceName, userCredentials.deviceDescription);

        Storage::instance().saveUserCredentials(newCredentials);
        vTaskDelay(pdMS_TO_TICKS(500));
    }

    authenticateWithServer(networkConnectionController);
    return true;
}

void CommonSetup::authenticateWithServer(NetworkConnectionControllerBase* networkConnectionController) {
    bool networkConnectionProviderInitialized = NetworkConnectionProvider::init(networkConnectionController);

    if (networkConnectionProviderInitialized) {
        bool authenticated = AuthenticationController::instance().init();

        if (authenticated) {
            ESP_LOGI(TAG, "###AUTHENTICATED WITH SERVER");

            bool mqttInitialized = MqttProvider::get()->init();
            if (mqttInitialized) {
                SensorsController::instance().init();
            } else {
                ESP_LOGE(TAG, "Could not initialize MQTT...");
            }
        }
    } else {
        ESP_LOGE(TAG, "Could not initialize network connection provider... Is server on?");
    }
}
