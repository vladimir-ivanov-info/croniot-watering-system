/*#include "WifiHttpController.h"
#include "../NetworkManager.h"

Result WifiHttpController::sendHttpPost(String content, String route){
    Result result(false, "Default result");

    HTTPClient http;

    String serverAddress = NetworkManager::instance().serverAddress;
    uint16_t serverPort = NetworkManager::instance().serverPort;

    String serverRegisterCLientUrl = "http://" + serverAddress + ":" + String(serverPort) + route;

    http.begin(serverRegisterCLientUrl);

    http.addHeader("Content-Type", "application/json");
    int httpResponseCode = http.POST(content);
    if (httpResponseCode > 0) {
        Serial.print("HTTP Response code: ");
        Serial.println(httpResponseCode);

        String response = http.getString();
        if(!response.isEmpty()){
          result = parseResult(response);
        } else {
          Serial.println("HTTP response body is empty for endpoint: " + route);
        }
    } else {
        Serial.print("HTTP Request failed. Error code: ");
        Serial.println(httpResponseCode);
        result = Result(false, String(httpResponseCode));
    }

    http.end();

    return result;
}



*/


#include "WifiHttpController.h"
#include "../NetworkManager.h"
#include "esp_log.h"
#include "esp_http_client.h"

#define TAG "WifiHttpController"

Result WifiHttpController::sendHttpPost(const std::string& content, const std::string& route) {
    Result result(false, "Default result");

    std::string serverAddress = NetworkManager::instance().serverAddress;
    uint16_t port = NetworkManager::instance().serverPort;

    std::string url = "http://" + serverAddress + ":" + std::to_string(port) + route;

    ESP_LOGI(TAG, "Sending POST to URL: %s", url.c_str());

    esp_http_client_config_t config = {
        .url = url.c_str(),
        .method = HTTP_METHOD_POST,
        .timeout_ms = 5000
    };

    esp_http_client_handle_t client = esp_http_client_init(&config);
    esp_http_client_set_header(client, "Content-Type", "application/json");
    esp_http_client_set_post_field(client, content.c_str(), content.length());

    esp_err_t err = esp_http_client_perform(client);

    if (err == ESP_OK) {
        int status = esp_http_client_get_status_code(client);
        ESP_LOGI(TAG, "HTTP POST Status = %d", status);

        int contentLength = esp_http_client_get_content_length(client);
        std::string response;
        if (contentLength > 0) {
            char* buffer = new char[contentLength + 1];
            int readLen = esp_http_client_read_response(client, buffer, contentLength);
            if (readLen >= 0) {
                buffer[readLen] = '\0';
                response = std::string(buffer);
                result = parseResult(response);
            } else {
                ESP_LOGW(TAG, "No response body received");
            }
            delete[] buffer;
        }
    } else {
        ESP_LOGE(TAG, "HTTP POST request failed: %s", esp_err_to_name(err));
        result = Result(false, esp_err_to_name(err));
    }

    esp_http_client_cleanup(client);
    return result;
}
