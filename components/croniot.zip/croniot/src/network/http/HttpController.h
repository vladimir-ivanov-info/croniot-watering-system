/*#ifndef HTTPCONTROLLER_H
#define HTTPCONTROLLER_H

#include "Result.h"

class HttpController {

    public:
        virtual Result sendHttpPost(String content, String route) = 0;

        virtual ~HttpController() = default;

    protected:
        Result parseResult(const String& jsonString) {
            JsonDocument doc;

            DeserializationError error = deserializeJson(doc, jsonString);

            if (error) {
                Serial.print(F("deserializeJson() failed: "));
                Serial.println(error.f_str());
                // Return a default Result object with success as false and empty message
                return Result(false, "Local deserializeJson() failed, JSON:\n" + jsonString);
            }

            bool success = doc["success"];
            String message = doc["message"];

            return Result(success, message);
        }
};
    

#endif

*/



#pragma once

#include <string>
#include "../../Result.h"
#include "esp_log.h"
#include "cJSON.h"

class HttpController {
public:
    virtual Result sendHttpPost(const std::string& content, const std::string& route) = 0;
    virtual ~HttpController() = default;

protected:
    Result parseResult(const std::string& jsonString) {
        const char* TAG = "HttpController";

        cJSON* root = cJSON_Parse(jsonString.c_str());
        if (!root) {
            ESP_LOGE(TAG, "cJSON_Parse() failed: %s", cJSON_GetErrorPtr());
            return Result(false, "Local cJSON_Parse() failed, JSON:\n" + jsonString);
        }

        cJSON* successItem = cJSON_GetObjectItem(root, "success");
        cJSON* messageItem = cJSON_GetObjectItem(root, "message");

        bool success = (successItem && cJSON_IsBool(successItem)) ? cJSON_IsTrue(successItem) : false;
        std::string message = (messageItem && cJSON_IsString(messageItem)) ? messageItem->valuestring : "";

        cJSON_Delete(root);

        return Result(success, message);
    }
};
