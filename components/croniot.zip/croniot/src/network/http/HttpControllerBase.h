/*#ifndef HTTPCONTROLLERBASE_H
#define HTTPCONTROLLERBASE_H

#include "Result.h"

class HttpControllerBase{
    
    public:
        virtual bool init() = 0;


        Result parseResult(const String& jsonString) {

            JsonDocument doc;
            DeserializationError error = deserializeJson(doc, jsonString);
          
            if (error) {
              Serial.print(F("deserializeJson() failed: "));
              Serial.println(error.f_str());
              return Result(false, "Local deserializeJson() failed, JSON:\n" + jsonString);
            }
          
            bool success = doc["success"];
            String message = doc["message"];
          
            return Result(success, message);
          }

    private:


};

#endif


*/


#pragma once

#include <string>
#include "esp_log.h"
#include "cJSON.h"
#include "Result.h"

class HttpControllerBase {
public:
    virtual bool init() = 0;

    Result parseResult(const std::string& jsonString) {
        const char* TAG = "HttpController";

        cJSON* root = cJSON_Parse(jsonString.c_str());
        if (!root) {
            ESP_LOGE(TAG, "cJSON_Parse() failed: %s", cJSON_GetErrorPtr());
            return Result(false, "Local cJSON_Parse() failed, JSON:\n" + jsonString);
        }

        cJSON* successItem = cJSON_GetObjectItem(root, "success");
        cJSON* messageItem = cJSON_GetObjectItem(root, "message");

        bool success = (successItem && cJSON_IsBool(successItem)) ? cJSON_IsTrue(successItem) : false;
        std::string message = (messageItem && cJSON_IsString(messageItem)) ? messageItem->valuestring : "";

        cJSON_Delete(root);

        return Result(success, message);
    }

    virtual ~HttpControllerBase() = default;
};
