// #include "WifiMqttController.h"

// bool WifiMqttController::init(){
//     mqttClient.onConnect([this](bool sessionPresent) {
//         this->onMqttConnect(sessionPresent);
//     });

// //mqttClient.onDisconnect(onMqttDisconnect);

//     mqttClient.onSubscribe([this](uint16_t packetId, uint8_t qos) {
//         this->onMqttSubscribe(packetId, qos);
//     });

// //mqttClient.onUnsubscribe(onMqttUnsubscribe);
//     //mqttClient.onMessage(onMqttMessage);


//     mqttClient.onMessage([this](char* topic, char* payload, AsyncMqttClientMessageProperties properties, size_t len, size_t index, size_t total) {
//         this->onMqttMessage(topic, payload, properties, len, index, total);
//     });

// //mqttClient.onPublish(onMqttPublish);

//     //ServerData serverData = Storage::instance().getServerData();

//     uint16_t serverMqttPort = NetworkManager::instance().serverMqttPort;
//     mqttClient.setServer("51.77.195.204", serverMqttPort);

//     Serial.println("Connecting to MQTT...");
//     mqttClient.connect();

//     return true;
// }

// void WifiMqttController::registerCallback(String topic, TaskBase* taskInstance) {
//     topicTaskMap[topic] = taskInstance;
    
//     uint16_t pcketId = mqttClient.subscribe(topic.c_str(), 2);
//     if (pcketId > 0) {
//         Serial.print("MQTT callback registered: ["); Serial.print(topic); Serial.println("]");
//     } else {
//         Serial.print("Failed to subscribe to topic: ["); Serial.print(topic); Serial.print("]");
//     }
// }

// void WifiMqttController::uninit(){
//     //client.disconnect();
// }

// Result WifiMqttController::publish(String topic, String message){
//     try{
//         if (xSemaphoreTake(mutex, portMAX_DELAY) == pdTRUE) {
//             if(mqttClient.connected()){
//                     uint16_t packetIdPub2 = mqttClient.publish(topic.c_str(), 2, false, message.c_str());
//                         if (packetIdPub2 == 0) {
//                             Serial.println("Failed to publish message. Packet ID is 0.");
//                         }
//             } else {
//                 mqttClient.disconnect();
//                 vTaskDelay(1000 / portTICK_PERIOD_MS);
//                 reconnectMQTT();
//             }
//             xSemaphoreGive(mutex); // Release the mutex
//         }
//     } catch(const std::exception& e){
//         Serial.println(">>>>>>>>>Exception in MQTTManager::publish");
//         Serial.println("<<<<<<<<<<");
//         xSemaphoreGive(mutex); // Release the mutex
//     }

//     return Result(true, "wqeqweqwe");
// }

// void WifiMqttController::reconnectMQTT() {
//     if (!mqttClient.connected()) {
//         Serial.println("Attempting MQTT reconnect...");
//         mqttClient.connect();
//     }
// }

// void WifiMqttController::onMqttDisconnect(AsyncMqttClientDisconnectReason reason) {
//     Serial.println("Disconnected from WiFi and MQTT.");

//     /*if (WiFi.isConnected()) {
//         mqttReconnectTimer.once(2, connectToMqtt);
//     }*/
// }

// void WifiMqttController::connectToMqtt() {
//     Serial.println("Connecting to MQTT...");
//     mqttClient.connect();
// }

// void WifiMqttController::onMqttConnect(bool sessionPresent) {
//     initialized = true;
//     Serial.println("MQTT connected.");
// }

// void WifiMqttController::onMqttSubscribe(uint16_t packetId, uint8_t qos) {
//     /*Serial.println("Subscribe acknowledged.");
//     Serial.print("  packetId: ");
//     Serial.println(packetId);
//     Serial.print("  qos: ");
//     Serial.println(qos);*/
// }

// void WifiMqttController::onMqttMessage(char* topic, char* payload, AsyncMqttClientMessageProperties properties, size_t len, size_t index, size_t total) {
//     String topicStr = String(topic);
//     Serial.print("MQTT message arrived on topic: "); Serial.println(topicStr);

//     int subTopicsCount = 0;
//     String *subTopics = StringUtil::split(topicStr, "/", subTopicsCount);
    
//     String taskType = subTopics[subTopicsCount - 1];
//     Serial.print("Task type: "); Serial.println(taskType);
    
//     TaskController::instance().processMessage(taskType.toInt(), String(payload), len);
// }


#include "WifiMqttController.h"
#include "network/NetworkManager.h"
#include "Tasks/TaskController.h"

#define TAG "WifiMqttController"

/*bool WifiMqttController::init() {
    if (!mutex) {
        mutex = xSemaphoreCreateMutex();
    }

    esp_mqtt_client_config_t config = {
        .uri = ("mqtt://" + NetworkManager::instance().serverAddress + ":" + std::to_string(NetworkManager::instance().serverMqttPort)).c_str()
    };

    mqttClient = esp_mqtt_client_init(&config);
    esp_mqtt_client_register_event(mqttClient, ESP_EVENT_ANY_ID, &mqttEventHandler, this);

    ESP_LOGI(TAG, "Connecting to MQTT...");
    return esp_mqtt_client_start(mqttClient) == ESP_OK;
}*/

/*bool WifiMqttController::init() {
    if (!mutex) {
        mutex = xSemaphoreCreateMutex();
    }

    esp_mqtt_client_config_t config = {};
    config.broker.address.hostname = NetworkManager::instance().serverAddress.c_str();
    config.broker.address.port = NetworkManager::instance().serverMqttPort;

    mqttClient = esp_mqtt_client_init(&config);
    esp_mqtt_client_register_event(mqttClient, ESP_EVENT_ANY_ID, &mqttEventHandler, this);

    ESP_LOGI(TAG, "Connecting to MQTT...");
    return esp_mqtt_client_start(mqttClient) == ESP_OK;
}*/

bool WifiMqttController::init() {
    if (!mutex) {
        mutex = xSemaphoreCreateMutex();
    }

    static std::string uriStr;  // static para que el puntero siga válido al iniciar MQTT
    uriStr = "mqtt://" + NetworkManager::instance().serverAddress + ":" + std::to_string(NetworkManager::instance().serverMqttPort);

    esp_mqtt_client_config_t config = {};
    config.broker.address.uri = uriStr.c_str();  // ⚠️ Usar 'broker.address.uri' en ESP-IDF 5.x

    mqttClient = esp_mqtt_client_init(&config);

    // Cast explícito porque ESP_EVENT_ANY_ID es int, y esp_mqtt_event_id_t es enum class
    esp_mqtt_client_register_event(
        mqttClient,
        static_cast<esp_mqtt_event_id_t>(ESP_EVENT_ANY_ID),
        &mqttEventHandler,
        this
    );

    ESP_LOGI(TAG, "Connecting to MQTT...");
    return esp_mqtt_client_start(mqttClient) == ESP_OK;
}



Result WifiMqttController::publish(const std::string& topic, const std::string& message) {
    if (!mqttClient) return Result(false, "MQTT not initialized");

    if (xSemaphoreTake(mutex, pdMS_TO_TICKS(1000)) == pdTRUE) {
        int msgId = esp_mqtt_client_publish(mqttClient, topic.c_str(), message.c_str(), 0, 1, 0);
        xSemaphoreGive(mutex);
        if (msgId > 0) {
            return Result(true, "Published successfully");
        }
        return Result(false, "Publish failed");
    }

    return Result(false, "MQTT publish mutex timeout");
}

void WifiMqttController::registerCallback(const std::string& topic, TaskBase* taskInstance) {
    topicTaskMap[topic] = taskInstance;

    if (mqttClient) {
        int msgId = esp_mqtt_client_subscribe(mqttClient, topic.c_str(), 1);
        ESP_LOGI(TAG, "Subscribed to topic: %s (msgId: %d)", topic.c_str(), msgId);
    }
}

void WifiMqttController::mqttEventHandler(void* handler_args, esp_event_base_t base, int32_t event_id, void* event_data) {
    auto* controller = static_cast<WifiMqttController*>(handler_args);
    esp_mqtt_event_handle_t event = static_cast<esp_mqtt_event_handle_t>(event_data);

    switch (event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT connected");
            controller->initialized = true;
            break;

        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "MQTT disconnected");
            controller->initialized = false;
            break;

        case MQTT_EVENT_DATA:
            if (event->topic_len > 0 && event->data_len > 0) {
                std::string topic(event->topic, event->topic_len);
                std::string payload(event->data, event->data_len);
                controller->handleMessage(topic, payload);
            }
            break;

        default:
            break;
    }
}

void WifiMqttController::handleMessage(const std::string& topic, const std::string& payload) {
    ESP_LOGI(TAG, "Message received on topic: %s", topic.c_str());

    auto it = topicTaskMap.find(topic);
    if (it != topicTaskMap.end()) {
        // Puedes pasar payload a tu task directamente o procesarlo como string.
        TaskController::instance().processMessage(/*tipo*/0, payload, payload.length());
    } else {
        ESP_LOGW(TAG, "No handler registered for topic: %s", topic.c_str());
    }
}
