#include "NetworkConnectionControllerBase.h"

NetworkConnectionControllerBase::~NetworkConnectionControllerBase() {
    // destructor virtual obligatorio para que se genere el vtable
}
