#include <cstring>
#include "WifiNetworkConnectionController.h"

// Inicialización singleton
bool WifiNetworkConnectionController::init() {
    wifiConnected = false;

    // Inicializa NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ESP_ERROR_CHECK(nvs_flash_init());
    }

    // Inicializa TCP/IP y loop de eventos
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    // Configura Wi-Fi
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        WIFI_EVENT, ESP_EVENT_ANY_ID,
        &WifiNetworkConnectionController::wifiEventHandler,
        this, nullptr));
    ESP_ERROR_CHECK(esp_event_handler_instance_register(
        IP_EVENT, IP_EVENT_STA_GOT_IP,
        &WifiNetworkConnectionController::wifiEventHandler,
        this, nullptr));

    // Arranca Wi-Fi
    wifi_config_t wifi_cfg = {};
    auto& nm = NetworkManager::instance();
    strncpy((char*)wifi_cfg.sta.ssid, nm.wifiSsid.c_str(), sizeof(wifi_cfg.sta.ssid));
    strncpy((char*)wifi_cfg.sta.password, nm.wifiPassword.c_str(), sizeof(wifi_cfg.sta.password));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    ESP_LOGI(TAG_WIFI, "Wi-Fi started, connecting to '%s'", nm.wifiSsid.c_str());
    return true;
}

void WifiNetworkConnectionController::wifiEventHandler(void* arg,
    esp_event_base_t base, int32_t id, void* /*data*/)
{
    auto& inst = WifiNetworkConnectionController::instance();

    if (base == WIFI_EVENT && id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG_WIFI, "Disconnected");
        inst.setWifiConnected(false);
        NetworkManager::instance().setConnectedToWifi(false);
        esp_wifi_connect();
    }
    else if (base == IP_EVENT && id == IP_EVENT_STA_GOT_IP) {
        ESP_LOGI(TAG_WIFI, "Got IP");
        inst.setWifiConnected(true);
        NetworkManager::instance().setConnectedToWifi(true);

        // Crea la tarea MQTT sólo una vez
        if (!inst.taskCreated) {
            inst.taskCreated = true;
            xTaskCreatePinnedToCore(
                &WifiNetworkConnectionController::mqttTask,
                "mqtt_task",
                8192,
                &inst,
                tskIDLE_PRIORITY + 1,
                &inst.mqttTaskHandle,
                tskNO_AFFINITY
            );
        }
    }
}

void WifiNetworkConnectionController::setWifiConnected(bool connected) {
    // Configura el pin LED
    gpio_config_t io_conf = {
        .pin_bit_mask = 1ULL << ledPin,
        .mode         = GPIO_MODE_OUTPUT,
        .pull_up_en   = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type    = GPIO_INTR_DISABLE
    };
    gpio_config(&io_conf);

    gpio_set_level(ledPin, connected ? 0 : 1);
    wifiConnected = connected;
}

bool WifiNetworkConnectionController::connectedToNetwork() {
    return wifiConnected;
}

void WifiNetworkConnectionController::mqttTask(void* pvParameters) {
    auto* inst = static_cast<WifiNetworkConnectionController*>(pvParameters);
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(500));
        inst->handleMqtt();
        esp_task_wdt_reset();
    }
}

void WifiNetworkConnectionController::handleMqtt() {
    if (!wifiConnected) {
        return;
    }
    if (!authInitDone) {
        AuthenticationController::instance().init();
        authInitDone = true;
    }

    auto* mqtt = MqttProvider::get();
    if (mqtt && mqtt->initialized) {
        if (!taskCtrlInitDone) {
            TaskController::instance().init();
            taskCtrlInitDone = true;
        }
    }
}
