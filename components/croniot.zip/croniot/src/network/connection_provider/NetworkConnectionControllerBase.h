#ifndef NETWORK_CONNECTION_CONTROLLER_BASE_H
#define NETWORK_CONNECTION_CONTROLLER_BASE_H

#include "esp_task_wdt.h"

class NetworkConnectionControllerBase {
public:
    virtual bool init() = 0;
    virtual bool connectedToNetwork() = 0;  // Puedes dejarlo como método virtual no puro si tiene implementación

    virtual ~NetworkConnectionControllerBase() = default;
};

#endif