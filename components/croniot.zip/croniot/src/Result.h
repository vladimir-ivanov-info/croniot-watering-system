// #ifndef RESULT_H
// #define RESULT_H

// #include "cJSON.h"

// class Result{

//     public:
//         Result(){}
//         Result(bool success, String message) : success(success), message(message){}

//         bool success;
//         String message;

//         String toString();

//     private:


// };

// #endif

#ifndef RESULT_H
#define RESULT_H

#include <string>

class Result {
public:
    Result() = default;
    Result(bool success, const std::string& message)
        : success(success), message(message) {}

    bool success;
    std::string message;

    std::string toString() const;

private:
};

#endif
